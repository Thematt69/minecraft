 
Thanks for downloading Captive Minecraft IV: Winter Realm!

Please check out thefarlanders.com/captiveminecraftiv for all information about getting the map up and running, as well as troubleshooting any issues. To install, drag the folder “Captive Minecraft” into your world saves folder.

If you’re running Captive Minecraft on a multiplayer server, please ensure you have command blocks enabled in the server.properties file. The game was designed for Minecraft 1.11, and cannot be played in any earlier version of Minecraft. 

As always, thanks for playing! 


- Farlander

youtube.com/fromthefarlands
twitter.com/thefarlanders