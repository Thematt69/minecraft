Thank you for downloading this map!

~~~~*IMPORTANT*~~~~
1.Don't play this map on Bukkit!
2.Turn Commandblocks on!
3.PvP off if you prefer!

~~~~*INSTALLATION*~~~~
1.Unzip the archive
2.Drag and drop the folder "Bowling by Merphin" into "C:\Users\*USER*\AppData\Roaming\.minecraft\saves"
3.Start Minecraft
4.Play the map

~~~~*INFO*~~~~
The map was built by Merphin
I would really appreciate it if anyone would make a Let's Play of this!
Please inform me, if you have found a bug!

Have fun and enjoy!